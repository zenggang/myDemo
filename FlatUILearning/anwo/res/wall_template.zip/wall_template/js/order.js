var cities = {
    '1' : '北京市',
    '2' : '江西省',
    '3' : '河北省',
    '4' : '陕西省',
    '5' : '贵州省',
    '6' : '黑龙江省',
    '7' : '浙江省',
    '8' : '云南省',
    '9' : '四川省',
    '10' : '河南省',
    '11' : '山东省',
    '12' : '广西壮族自治区',
    '13' : '内蒙古自治区',
    '14' : '广东省',
    '15' : '海南省',
    '16' : '青海省',
    '17' : '江苏省',
    '18' : '湖北省',
    '19' : '上海市',
    '20' : '宁夏回族自治区',
    '21' : '重庆市',
    '22' : '甘肃省',
    '23' : '福建省',
    '24' : '辽宁省',
    '25' : '山西省',
    '26' : '吉林省',
    '27' : '天津市',
    '28' : '湖南省',
    '29' : '安徽省',
    '30' : '新疆维吾尔自治区',
    '31' : '台湾省',
    '32' : '香港特别行政区',
    '33' : '澳门特别行政区',
    '34' : '西藏自治区'
};

var attributeString;

window.onload = function(){
    window.location = "adwo://adwoFetchSubmitAttributes";
}

function adwoFetchAttributesString(attrStr)
{
    attributeString = attrStr;
}

$(function() {
    //loadProData();

    $("#submit").bind('click', function() {
        // track
        //track(pageid, orderBtnClicked);        
        submitData();
    });
    
    // track
    track(pageid, homePV);
});

function loadProData() {
    var proOption = "<option value=''>请选择省份</option>";
    for (var i in cities) {
        proOption += "<option id="+i+" value='" + cities[i] + "'>" + cities[i] + "</option>";
    }
    $("#province").empty().append(proOption).bind('change', function() {
        if (!$(this).val()) {
            return
        }
        loadCityData($(this).find('option:checked').attr('id'));
    });
}

function loadCityData(pro) {
    var cityOption = "<option value=''>请选择城市</option>";
    for (var j in city) {
        if (city[j]["parent"] == pro) {
            cityOption += "<option value='" + city[j]["name"] + "'>" + city[j]["name"] + "</option>";
        }
    }
    $("#city").empty().append(cityOption);
}

function submitData() {
    var app_id = $("#expand1").val(),app_name = $("#expand1 option:selected").text(),description = $("#description").val(), email = $("#email").val(),reg_email = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\.[a-zA-Z0-9_-]{2,3}){1,2})$/;
    var feedbacktype = $(".feedbacktype.selected").text();
    if (!app_id || app_id==="请选择App名称") {
        alert("请选择App名称");
        return
    }
    if (!description || description==="请填写反馈意见") {
        alert("请填写反馈意见");
        return
    }
    if (!email || !reg_email.test(email)) {
        alert("请填写正确邮箱");
        return
    }

    var url = "http://track.mobile1.com.cn/advmessage/adv/addResultJsonP.action?advid=115" + attributeString;

    $.ajax({
        url : url,
        cache : false,
        dataType : 'jsonp',
        jsonpCallback : "eventcallback",
        data : {
           expand1 : app_name,
		   expand2 : app_id,
		   expand3 : feedbacktype,
           description : description,
           email : email
        },
        success : function(json) {
			
            if (json[0].success == 1) {
                alert("恭喜，反馈意见提交成功！");
				history.back();
            } else {
                alert(json[0].info)
            }
        }
    });
}
